myAppBeforeLogin.controller('myAppBeforeLoginController', function($scope,$routeParams,$rootScope) {
		
});