package com.service;


public interface CommonService {
	public void getUser();
}
