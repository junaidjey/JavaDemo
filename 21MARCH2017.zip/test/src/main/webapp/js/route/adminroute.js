var myAppAdmin  = angular.module('myAppAdmin',['ngRoute','ui.bootstrap','ngCookies','ngResource']);
var _contextPath= _path + '/jsps/admin';
myAppAdmin.config([ '$routeProvider', '$httpProvider', function($routeProvider, $httpProvider) {
	$routeProvider.
	when('/dashboard', {
		templateUrl : _contextPath + '/dashboard/dashboard.jsp',
		controller : 'admincontroller',
	}).otherwise({
		templateUrl : _contextPath + '/dashboard/dashboard.jsp',
		controller : 'admincontroller',
	});
	if (!$httpProvider.defaults.headers.get) {
		$httpProvider.defaults.headers.get = {};
	}
	$httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
	$httpProvider.defaults.headers.post['X-CSRF-TOKEN']=$("meta[name='_csrf']").attr("content");
	 $httpProvider.defaults.withCredentials = true;
} 
]);