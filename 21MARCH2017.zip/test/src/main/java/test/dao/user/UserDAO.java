package test.dao.user;

import test.model.User;

public interface UserDAO {

	User getUser(String login);

}
