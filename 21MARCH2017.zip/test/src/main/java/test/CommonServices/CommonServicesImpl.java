package test.CommonServices;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@Repository
public class CommonServicesImpl implements CommonServices{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void inserRole() {
		System.out.println("Insert Role function In common Service Impl called");
	}
}
