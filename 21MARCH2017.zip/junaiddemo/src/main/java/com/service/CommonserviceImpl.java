package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.CommonDAO;

@Service
//@Transactional
public class CommonserviceImpl implements CommonService{
	
	@Autowired
	private CommonDAO commonDAO;
	
	@Override
	public void getUser() {
		commonDAO.getUser();
	}

}
