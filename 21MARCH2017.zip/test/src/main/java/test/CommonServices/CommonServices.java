package test.CommonServices;

public interface CommonServices {

	void inserRole();

}
