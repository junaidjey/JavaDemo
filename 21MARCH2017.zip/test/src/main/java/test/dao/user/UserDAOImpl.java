package test.dao.user;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import test.model.User;

@Repository
public class UserDAOImpl implements UserDAO{
	@Autowired
	SessionFactory sessionFactory;
	@Transactional
	@Override
	@SuppressWarnings("unchecked")
	public User getUser(String emailAddress) {
		System.out.println("getUser="+emailAddress);
		List<User> userList= new ArrayList<User>();
		Query query = sessionFactory.getCurrentSession().createQuery("FROM User WHERE emailAddress =:emailAddress");
		query.setParameter("emailAddress", emailAddress);
		userList = query.list();
		System.out.println("query="+query.list()+" size="+query.list().size());
		if (userList.size() > 0) {
			return userList.get(0);
		} else {
			return null;
		}
	}

}
