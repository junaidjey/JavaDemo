myAppWebsite.controller('usercontroller', function($scope,$routeParams,$rootScope) {
	/*alert("user controller");*/
});