package test.service.user;

public interface UserService {

}
