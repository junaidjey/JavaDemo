var myAppBeforeLogin  = angular.module('myAppBeforeLogin',['ngRoute','ui.bootstrap','ngCookies','ngResource']);
var _contextPath= _path + '/jsps';
myAppBeforeLogin.config([ '$routeProvider', '$httpProvider', function($routeProvider, $httpProvider) {
	$routeProvider.
	when('/login', {
		templateUrl : _contextPath + '/login.jsp',
		controller : 'myAppBeforeLoginController',
	}).otherwise({
		templateUrl : _contextPath + '/login.jsp',
		controller : 'myAppBeforeLoginController',
	});
	if (!$httpProvider.defaults.headers.get) {
		$httpProvider.defaults.headers.get = {};
	}
	$httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
	$httpProvider.defaults.headers.post['X-CSRF-TOKEN']=$("meta[name='_csrf']").attr("content");
	 $httpProvider.defaults.withCredentials = true;
} 
]);