package test.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import test.dao.user.UserDAO;
import test.model.User;

@Service("CustomUserDetailsService")
@Transactional(readOnly=true)
public class CustomUserDetailsService implements UserDetailsService{
	@Autowired
	UserDAO userDAO;
	@Override
	public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
		System.out.println("email addess from customService="+login);
		User user=userDAO.getUser(login);
		/*System.out.println("customUserData loadUserByUsername line 23="+user.getEmailAddress());
		System.out.println("customUserData loadUserByUsername line 24="+user.getUserId());
		System.out.println("user Role"+user.getUserType());*/
		return  buildUserForAuthentication(user);
	}
	private org.springframework.security.core.userdetails.User buildUserForAuthentication(User user) {

		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		try {
			authorities.add(new SimpleGrantedAuthority(user.getUserType()));

			List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(authorities);
			String u = user.getEmailAddress().toString();
			String p = user.getPassword().toString();
			System.out.println("Username>>" + u + "  Passowrd  " + p);
			return new org.springframework.security.core.userdetails.User(u, p, true, true, true, true, Result);
		} catch (Exception e) {
			return new org.springframework.security.core.userdetails.User("null", "null", false, false, false, false,  new ArrayList<GrantedAuthority>(authorities));
			// TODO: handle exception
		}
	}
}
