package test.Controller;

import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import test.service.user.UserService;

@RestController
public class LoginController {
	@Autowired
	UserService userService;
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView login(
			@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {
			System.out.println("inside login");
			ModelAndView model = new ModelAndView();
			
			if (error != null) {
				System.out.println("error !== null");
				model.addObject("error", "Invalid username and password!");
			}
			
			if (logout != null) {
				
				System.out.println("TTTTTTTTTTTTTTTTTTTpublic index");
				model.addObject("msg", "You've been logged ou`t successfully.");
			}
			/*model.setViewName("/login");*/
			model.setViewName("/index");
			return model;
		}
	
	@RequestMapping(value="/accessDenied", method=RequestMethod.GET)
	public ModelAndView accessDenied() {
		System.out.println("access denied page call");
		return new ModelAndView("/accessdenied");
	}
	@RequestMapping(value="/index1", method=RequestMethod.GET)
	public ModelAndView index1() {
		System.out.println("inside logout index1");
	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (!(auth instanceof AnonymousAuthenticationToken))
		    {
		        return new ModelAndView("/index");
		    }else{
		return new ModelAndView("index1");
		    }
	}
	@RequestMapping(value="/index", method=RequestMethod.GET)
	public ModelAndView index() {
		System.out.println("Redirect Controller Call ModelAndView line 72");
		try {
			System.out.println("public ModelAndView index()");
			org.springframework.security.core.userdetails.User user = (org.springframework.security.core.userdetails.User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			System.out.println("public ModelAndView index() after user"+user.toString());
		} catch (Exception e) {
			return new ModelAndView("/index");
		}
		System.out.println("Redirect Controller Call ModelAndView line 81=");
		try {
			Collection<SimpleGrantedAuthority> sg =   (Collection<SimpleGrantedAuthority>) SecurityContextHolder.getContext().getAuthentication().getAuthorities();
			System.out.println("Your role is"+sg.size());
			if(sg.toString().equals("[user]")){
				return new ModelAndView("/website/websiteindex");
			}else if (sg.toString().equals("[admin]")) {
				return new ModelAndView("/admin/adminindex");
			}
		} catch (Exception e) {
			return new ModelAndView("/login");
		}
		return new ModelAndView("/login");	
	}
}
