package com.dao;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CommonDAOImpl implements CommonDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	@Transactional
	public void getUser() {
		System.out.println("userDAO");
		Query q= sessionFactory.getCurrentSession().createQuery("from User");
		//q.list();
		
		System.out.println(q.list().toString());
	}

}
