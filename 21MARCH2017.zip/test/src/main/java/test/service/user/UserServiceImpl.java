package test.service.user;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{

}
