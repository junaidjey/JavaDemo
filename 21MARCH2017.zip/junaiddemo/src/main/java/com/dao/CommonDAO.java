package com.dao;

public interface CommonDAO {

	public void getUser();
}
