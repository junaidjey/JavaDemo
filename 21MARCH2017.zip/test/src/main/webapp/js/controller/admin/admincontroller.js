myAppAdmin.controller('admincontroller', function($scope,$routeParams,$rootScope) {
	/*alert("admin controller");*/
});