package test.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import test.CommonServices.CommonServices;

public class InitiBean implements ApplicationListener<ContextRefreshedEvent>{
	@Autowired
	private CommonServices commonServices;
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		try {
			commonServices.inserRole();
		} catch (Exception e) {
		}
	}

}
